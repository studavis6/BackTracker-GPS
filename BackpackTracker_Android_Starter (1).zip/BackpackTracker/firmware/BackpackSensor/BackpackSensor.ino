/*
 * Seeed Studio XIAO nRF52840 (standard, non-Sense board works).
 * Arduino Boards Manager: Seeed nRF52 Boards (NON-mbed), board Seeed XIAO nRF52840.
 * BLE peripheral for the included Android app. No phone GPS or SD card needed here.
 *
 * TEST FIRST: momentarily bridge D0 to GND with a wire. Active = trigger ON.
 * Real Hall sensor: verify its datasheet and pinout before connecting.
 * D0 must NEVER exceed 3.3 V. A compatible open-drain sensor can use INPUT_PULLUP.
 */
#include <Adafruit_TinyUSB.h>
#include <bluefruit.h>

const int SENSOR_PIN = D0;
const bool ACTIVE_LOW = true; // Set false if the validated sensor is HIGH when trigger is pulled.
const uint32_t DEBOUNCE_MS = 30;
const uint32_t HEARTBEAT_MS = 1000;

// UUID bytes in Nordic / Bluefruit least-significant-byte-first order.
// Service: cf560001-3c3c-4a4b-9a11-c0a5ab120001
const uint8_t SERVICE_UUID[] = {0x01,0x00,0x12,0xab,0xa5,0xc0,0x11,0x9a,0x4b,0x4a,0x3c,0x3c,0x01,0x00,0x56,0xcf};
// Characteristic: cf560002-3c3c-4a4b-9a11-c0a5ab120001
const uint8_t STATE_UUID[] = {0x01,0x00,0x12,0xab,0xa5,0xc0,0x11,0x9a,0x4b,0x4a,0x3c,0x3c,0x02,0x00,0x56,0xcf};
BLEService triggerService(SERVICE_UUID);
BLECharacteristic triggerState(STATE_UUID);
bool lastRaw, stable;
uint32_t rawChangedAt, lastSentAt;

bool readTrigger() { return digitalRead(SENSOR_PIN) == (ACTIVE_LOW ? LOW : HIGH); }

void publish() {
    const uint8_t state = stable ? 1 : 0;
    triggerState.write(&state, 1); // Also allow initial characteristic read.
    if (Bluefruit.connected()) triggerState.notify(&state, 1);
    lastSentAt = millis();
}

void setup() {
    pinMode(SENSOR_PIN, INPUT_PULLUP);
    lastRaw = stable = readTrigger(); rawChangedAt = millis();
    Serial.begin(115200); // Do not wait for USB; standalone battery operation must work.
    Bluefruit.begin(1, 0);
    Bluefruit.setName("BackpackSensor");
    Bluefruit.setTxPower(0);
    triggerService.begin();
    triggerState.setProperties(CHR_PROPS_READ | CHR_PROPS_NOTIFY);
    triggerState.setPermission(SECMODE_OPEN, SECMODE_NO_ACCESS);
    triggerState.setFixedLen(1);
    triggerState.begin();
    publish();
    Bluefruit.Advertising.addFlags(BLE_GAP_ADV_FLAGS_LE_ONLY_GENERAL_DISC_MODE);
    Bluefruit.Advertising.addTxPower();
    Bluefruit.Advertising.addService(triggerService);
    Bluefruit.ScanResponse.addName();
    Bluefruit.Advertising.restartOnDisconnect(true);
    Bluefruit.Advertising.setInterval(160, 320);
    Bluefruit.Advertising.setFastTimeout(30);
    Bluefruit.Advertising.start(0);
}

void loop() {
    uint32_t now = millis();
    bool raw = readTrigger();
    if (raw != lastRaw) { lastRaw = raw; rawChangedAt = now; }
    bool changed = raw != stable && (uint32_t)(now - rawChangedAt) >= DEBOUNCE_MS;
    if (changed) stable = raw;
    if (changed || (uint32_t)(now - lastSentAt) >= HEARTBEAT_MS) publish();
    delay(5);
}

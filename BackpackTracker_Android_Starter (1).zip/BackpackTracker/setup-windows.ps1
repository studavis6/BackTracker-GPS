$ErrorActionPreference = 'Stop'
$wrapper = Join-Path $PSScriptRoot 'gradle\wrapper\gradle-wrapper.jar'
$temp = "$wrapper.download"
$checksum = "$wrapper.sha256.download"
try {
    Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/gradle/gradle/v8.9.0/gradle/wrapper/gradle-wrapper.jar' -OutFile $temp
    Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-8.9-wrapper.jar.sha256' -OutFile $checksum
    $expected = (Get-Content -Raw $checksum).Trim()
    $actual = (Get-FileHash -Algorithm SHA256 $temp).Hash.ToLowerInvariant()
    if ($expected -notmatch '^[0-9a-fA-F]{64}$' -or $actual -ne $expected.ToLowerInvariant()) { throw 'Gradle wrapper checksum mismatch' }
    Move-Item -Force $temp $wrapper
    Write-Host 'Gradle wrapper verified. Open this folder in Android Studio.'
} finally {
    if (Test-Path $temp) { Remove-Item $temp }
    if (Test-Path $checksum) { Remove-Item $checksum }
}

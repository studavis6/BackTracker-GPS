package org.backpacktracker;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Locale;

/** Flush each record so normal activity destruction does not discard buffered readings. */
public final class SessionWriter implements RecordingEngine.Sink, Closeable {
    private final BufferedWriter track, spray, events, points;
    public int trackCount, sprayCount;
    public SessionWriter(File dir) throws IOException {
        java.util.ArrayList<BufferedWriter> opened = new java.util.ArrayList<>();
        try {
            track = open(dir, "TRAKLOG1.TXT"); opened.add(track);
            spray = open(dir, "DATALOG1.TXT"); opened.add(spray);
            events = open(dir, "EVENTS.csv"); opened.add(events);
            points = open(dir, "POINTS.csv"); opened.add(points);
            line(track, RecordingEngine.HEADER); line(spray, RecordingEngine.HEADER);
            line(events, "Time_UTC,TriggerState,Reason");
            line(points, "Time_UTC,Latitude,Longitude,Accuracy_m,RecordType");
        } catch (IOException e) {
            for (BufferedWriter w : opened) { try { w.close(); } catch (IOException ignored) {} }
            throw e;
        }
    }
    private static BufferedWriter open(File dir, String name) throws IOException {
        return new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File(dir, name)), StandardCharsets.UTF_8));
    }
    private static void line(BufferedWriter out, String text) throws IOException {
        out.write(text); out.write("\r\n"); out.flush();
    }
    private void point(RecordingEngine.Fix f, String kind) throws IOException {
        line(points, String.format(Locale.US, "%s,%.6f,%.6f,%.2f,%s",
            Instant.ofEpochMilli(f.utcMs), f.latitude, f.longitude, f.accuracy, kind));
    }
    @Override public void track(RecordingEngine.Fix f) throws IOException {
        line(track, RecordingEngine.csv(f)); point(f, "ROUTE"); trackCount++;
    }
    @Override public void spray(RecordingEngine.Fix f) throws IOException {
        line(spray, RecordingEngine.csv(f)); point(f, "TRIGGER_ON"); sprayCount++;
    }
    @Override public void event(long utc, RecordingEngine.State state, String reason) throws IOException {
        line(events, Instant.ofEpochMilli(utc) + "," + state + "," + reason.replace(',', ';').replace('\n', ' '));
    }
    @Override public void close() throws IOException {
        IOException failure = null;
        for (BufferedWriter w : new BufferedWriter[]{track, spray, events, points}) {
            try { w.close(); } catch (IOException e) { failure = e; }
        }
        if (failure != null) throw failure;
    }
}

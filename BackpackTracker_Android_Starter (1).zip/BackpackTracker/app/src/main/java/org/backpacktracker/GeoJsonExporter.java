package org.backpacktracker;

import java.io.*;
import java.nio.charset.StandardCharsets;

/** Export discrete points only. Never infer a continuous treatment swath from point spacing. */
public final class GeoJsonExporter {
    public static void write(File points, OutputStream output) throws IOException {
        Writer writer = new OutputStreamWriter(output, StandardCharsets.UTF_8);
        writer.write("{\"type\":\"FeatureCollection\",\"features\":[");
        boolean first = true;
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(points), StandardCharsets.UTF_8))) {
            reader.readLine(); String line;
            while ((line = reader.readLine()) != null) {
                String[] p = line.split(",", -1);
                if (p.length != 5) throw new IOException("Invalid POINTS.csv row");
                try {
                    double lat = Double.parseDouble(p[1]), lon = Double.parseDouble(p[2]), accuracy = Double.parseDouble(p[3]);
                    if (!Double.isFinite(lat) || Math.abs(lat) > 90 || !Double.isFinite(lon) || Math.abs(lon) > 180
                        || !Double.isFinite(accuracy) || accuracy < 0) throw new NumberFormatException();
                    java.time.Instant.parse(p[0]);
                    if (!p[4].equals("ROUTE") && !p[4].equals("TRIGGER_ON")) throw new IllegalArgumentException();
                } catch (RuntimeException e) { throw new IOException("Invalid point fields", e); }
                if (!first) writer.write(','); first = false;
                writer.write("{\"type\":\"Feature\",\"geometry\":{\"type\":\"Point\",\"coordinates\":[" + p[2] + "," + p[1]
                    + "]},\"properties\":{\"time_utc\":\"" + p[0] + "\",\"accuracy_m\":" + p[3]
                    + ",\"record_type\":\"" + p[4] + "\"}}");
            }
        }
        writer.write("]}"); writer.flush(); // The caller owns the ZIP stream; never close it here.
    }
    private GeoJsonExporter() {}
}

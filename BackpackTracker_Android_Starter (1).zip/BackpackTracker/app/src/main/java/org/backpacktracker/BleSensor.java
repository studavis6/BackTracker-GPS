package org.backpacktracker;

import android.annotation.SuppressLint;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.Context;
import android.os.Handler;
import android.os.ParcelUuid;
import java.util.Collections;
import java.util.UUID;

/** The matching firmware sends a one-byte 0/1 reading every second and on changes. */
@SuppressLint("MissingPermission")
public final class BleSensor {
    public static final UUID SERVICE = UUID.fromString("cf560001-3c3c-4a4b-9a11-c0a5ab120001");
    public static final UUID STATE = UUID.fromString("cf560002-3c3c-4a4b-9a11-c0a5ab120001");
    private static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    public interface Listener { void status(String message); void reading(boolean on); void lost(); }
    private final Context context;
    private final Handler handler;
    private final Listener listener;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private boolean closed, scanning;
    private long generation;
    public BleSensor(Context c, Handler h, Listener l) { context = c; handler = h; listener = l; }
    public void start() {
        if (closed) return;
        BluetoothManager manager = context.getSystemService(BluetoothManager.class);
        BluetoothAdapter adapter = manager == null ? null : manager.getAdapter();
        if (adapter == null || !adapter.isEnabled()) {
            listener.status("Enable Bluetooth; retrying in 5 seconds");
            handler.postDelayed(this::start, 5000); return;
        }
        try {
            scanner = adapter.getBluetoothLeScanner();
            if (scanner == null) { handler.postDelayed(this::start, 5000); return; }
            listener.status("Searching for BackpackSensor (power only your sensor nearby)");
            scanning = true;
            scanner.startScan(Collections.singletonList(new ScanFilter.Builder()
                .setServiceUuid(new ParcelUuid(SERVICE)).build()),
                new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(), scan);
            long token = ++generation;
            handler.postDelayed(() -> {
                if (!closed && generation == token && scanning) {
                    stopScan(); listener.status("Sensor not found; retrying");
                    handler.postDelayed(this::start, 5000);
                }
            }, 15000);
        } catch (RuntimeException e) { retry("Bluetooth scan failed: " + e.getMessage()); }
    }
    private void stopScan() {
        if (scanning && scanner != null) { try { scanner.stopScan(scan); } catch (RuntimeException ignored) {} }
        scanning = false;
    }
    private final ScanCallback scan = new ScanCallback() {
        @Override public void onScanResult(int type, ScanResult result) {
            handler.post(() -> {
                if (closed || !scanning) return;
                stopScan(); listener.status("Connecting to sensor " + result.getDevice().getAddress());
                try {
                    gatt = result.getDevice().connectGatt(context, false, callback, BluetoothDevice.TRANSPORT_LE);
                    long token = ++generation;
                    handler.postDelayed(() -> {
                        if (!closed && generation == token) retry("Sensor connection timed out");
                    }, 20000);
                } catch (RuntimeException e) { retry("Cannot connect: " + e.getMessage()); }
            });
        }
        @Override public void onScanFailed(int code) { handler.post(() -> retry("Scan error " + code)); }
    };
    private final BluetoothGattCallback callback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt g, int status, int state) {
            handler.post(() -> {
                if (closed || g != gatt) return;
                if (status == BluetoothGatt.GATT_SUCCESS && state == BluetoothProfile.STATE_CONNECTED) {
                    if (!g.discoverServices()) retry("Service discovery failed");
                } else if (state == BluetoothProfile.STATE_DISCONNECTED || status != BluetoothGatt.GATT_SUCCESS) {
                    retry("Sensor disconnected; trigger UNKNOWN");
                }
            });
        }
        @Override public void onServicesDiscovered(BluetoothGatt g, int status) {
            handler.post(() -> {
                if (closed || g != gatt) return;
                BluetoothGattService service = g.getService(SERVICE);
                BluetoothGattCharacteristic ch = service == null ? null : service.getCharacteristic(STATE);
                BluetoothGattDescriptor desc = ch == null ? null : ch.getDescriptor(CCCD);
                if (status != BluetoothGatt.GATT_SUCCESS || desc == null || !g.setCharacteristicNotification(ch, true)) {
                    retry("Sensor does not expose expected trigger service"); return;
                }
                desc.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                if (!g.writeDescriptor(desc)) retry("Cannot enable sensor notifications");
            });
        }
        @Override public void onDescriptorWrite(BluetoothGatt g, BluetoothGattDescriptor desc, int status) {
            handler.post(() -> {
                if (closed || g != gatt) return;
                if (status != BluetoothGatt.GATT_SUCCESS) { retry("Notification subscription failed"); return; }
                ++generation; // Cancel connection timeout. Wait for a valid heartbeat before reporting state.
                listener.status("Sensor connected; waiting for reading");
                BluetoothGattCharacteristic ch = g.getService(SERVICE).getCharacteristic(STATE);
                g.readCharacteristic(ch);
            });
        }
        @Override public void onCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic c, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) deliver(g, c.getUuid(), c.getValue());
        }
        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c) {
            deliver(g, c.getUuid(), c.getValue());
        }
    };
    private void deliver(BluetoothGatt g, UUID uuid, byte[] value) {
        if (!STATE.equals(uuid) || value == null || value.length != 1 || (value[0] != 0 && value[0] != 1)) return;
        boolean on = value[0] == 1;
        handler.post(() -> {
            if (!closed && g == gatt) { listener.status("Sensor connected"); listener.reading(on); }
        });
    }
    private void retry(String reason) {
        if (closed) return;
        ++generation; stopScan();
        BluetoothGatt old = gatt; gatt = null;
        if (old != null) { try { old.disconnect(); old.close(); } catch (RuntimeException ignored) {} }
        listener.lost(); listener.status(reason);
        handler.removeCallbacks(restart);
        handler.postDelayed(restart, 5000);
    }
    private final Runnable restart = this::start;
    public void close() {
        closed = true; ++generation; stopScan(); handler.removeCallbacks(restart);
        if (gatt != null) { try { gatt.disconnect(); gatt.close(); } catch (RuntimeException ignored) {} gatt = null; }
    }
}

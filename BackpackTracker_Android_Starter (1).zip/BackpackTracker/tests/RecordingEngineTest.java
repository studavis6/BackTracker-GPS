package org.backpacktracker;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;

public final class RecordingEngineTest {
    static int checks;
    static void check(boolean ok, String message) { checks++; if (!ok) throw new AssertionError(message); }
    static class Sink implements RecordingEngine.Sink {
        int track, spray; final ArrayList<RecordingEngine.State> states = new ArrayList<>();
        public void track(RecordingEngine.Fix f) { track++; }
        public void spray(RecordingEngine.Fix f) { spray++; }
        public void event(long t, RecordingEngine.State s, String reason) { states.add(s); }
    }
    static RecordingEngine.Fix fix(long elapsed) {
        return new RecordingEngine.Fix(1735689600000L + elapsed, elapsed, 39.1234567, -82.1234567,
            Double.NaN, 1.25, 5);
    }
    public static void main(String[] args) throws Exception {
        Sink s = new Sink(); RecordingEngine e = new RecordingEngine(0, s);
        for (int second = 0; second <= 9; second++) {
            long now = second * 1000L;
            e.tick(now, now, fix(now), RecordingEngine.State.ON, "TEST");
        }
        check(s.track == 3, "Track every 3 seconds");
        check(s.spray == 10, "Trigger on: immediate + 1 second intervals");
        e.tick(10000, 10000, fix(10000), RecordingEngine.State.OFF, "TEST");
        check(s.spray == 10, "No trigger point while off");
        e.tick(12000, 12000, fix(12000), RecordingEngine.State.UNKNOWN, "LOST");
        check(s.track == 4 && s.spray == 10, "Unknown continues route, excludes spraying");
        check(s.states.equals(Arrays.asList(RecordingEngine.State.ON, RecordingEngine.State.OFF, RecordingEngine.State.UNKNOWN)), "Record transitions only");
        e.tick(19000, 19000, fix(12000), RecordingEngine.State.ON, "STALE");
        check(s.track == 4 && s.spray == 10, "Reject stale GPS");
        RecordingEngine.Fix bad = new RecordingEngine.Fix(0, 20000, 39, -82, 0, 0, 26);
        e.tick(20000, 20000, bad, RecordingEngine.State.ON, "BAD_ACCURACY");
        check(s.spray == 10, "Reject poor accuracy");
        e.tick(21000, 21000, fix(21000), RecordingEngine.State.ON, "FRESH");
        e.tick(22000, 22000, fix(21000), RecordingEngine.State.ON, "DUPLICATE");
        check(s.spray == 11, "Do not repeat the same GPS fix in a file");
        check(RecordingEngine.sensorState(3500, 0, true) == RecordingEngine.State.UNKNOWN, "Heartbeat expires at boundary");
        check(RecordingEngine.sensorState(3499, 0, true) == RecordingEngine.State.ON, "Fresh heartbeat ON");
        check(RecordingEngine.sensorState(1000, 0, false) == RecordingEngine.State.OFF, "Fresh heartbeat OFF");
        check(RecordingEngine.sensorState(0, -1, false) == RecordingEngine.State.UNKNOWN, "Startup is UNKNOWN");
        check(RecordingEngine.sensorState(500, 1000, true) == RecordingEngine.State.UNKNOWN, "Reject future heartbeat");
        check(!new RecordingEngine.Fix(0, 0, Double.NaN, 0, 0, 0, 5).usable(0), "Reject NaN coordinates");
        check(!new RecordingEngine.Fix(0, 0, 0, -181, 0, 0, 5).usable(0), "Reject out of range coordinates");
        check(fix(0).usable(5000) && !fix(0).usable(5001), "Fix freshness boundary");
        Locale.setDefault(Locale.GERMANY); TimeZone.setDefault(TimeZone.getTimeZone("America/New_York"));
        String csv = RecordingEngine.csv(fix(0));
        check(csv.equals("2025-01-01,00:00:00,39.123457,-82.123457,,1.25,GPS Fix"), "UTC, decimal coordinates, blank unavailable elevation, stable locale");
        File dir = Files.createTempDirectory("backpack-test").toFile();
        try (SessionWriter writer = new SessionWriter(dir)) {
            writer.track(fix(3000)); writer.spray(fix(1000)); writer.event(1000, RecordingEngine.State.ON, "sensor,test");
        }
        String data = Files.readString(new File(dir, "DATALOG1.TXT").toPath());
        check(data.startsWith(RecordingEngine.HEADER + "\r\n"), "Exact original header and CRLF");
        check(data.split("\r\n").length == 2, "Header and one trigger record");
        ByteArrayOutputStream json = new ByteArrayOutputStream();
        GeoJsonExporter.write(new File(dir, "POINTS.csv"), json);
        String output = json.toString(StandardCharsets.UTF_8);
        check(output.contains("\"coordinates\":[-82.123457,39.123457]"), "GeoJSON longitude precedes latitude");
        check(output.contains("TRIGGER_ON") && output.contains("ROUTE"), "GeoJSON preserves record categories");
        File jsonFile = new File(dir, "points.geojson"); Files.writeString(jsonFile.toPath(), output);
        System.out.println("PASS: " + checks + " recording/export checks");
        System.out.println("GeoJSON test artifact: " + jsonFile);
    }
}

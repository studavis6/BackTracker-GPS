# Build the app without installing Android Studio

This option uses GitHub's computers to build an installable APK. Your Windows computer needs only a web browser and the ability to extract this small ZIP. The uploaded files contain code; your recorded GPS data stays on your phone and is not uploaded by this workflow.

The workflow has been prepared and checked, but it has NOT been run on GitHub yet. A successful green run is required before an APK will be available. No GitHub repository was created or uploaded on your behalf.

## 1. Create a private GitHub repository

1. Sign in or create an account at https://github.com .
2. Select **+ > New repository** (or visit https://github.com/new ).
3. Name it `backpack-tracker`.
4. Choose **Private** and select **Add a README file** / initialize with a README.
5. Select **Create repository**.

GitHub provides an included Actions allowance for private repositories, depending on the account plan. This is one manually started Linux job with a 20-minute timeout. It runs only when you select Run workflow, and retains its small APK artifact for seven days. Check your account's included allowance; no paid runner or billing upgrade is needed by the project itself. Do not enable paid usage simply to follow this guide.

## 2. Upload the extracted project contents

1. On Windows, right-click the downloaded project ZIP and choose **Extract All**.
2. Open the extracted `BackpackTracker` folder. You should see `settings.gradle`, `app`, `firmware`, and `.github` alongside these instructions.
3. On your repository's **Code** tab, choose **Add file > Upload files**.
4. Drag **all the CONTENTS of the BackpackTracker folder** from File Explorer into the upload area. Include the `.github` folder. Do not drag the outer `BackpackTracker` folder itself, and do not upload the ZIP as a single file.
5. Select **Commit changes** to save the upload to the default branch.

Correct repository layout:

| Item | Location in GitHub |
|---|---|
| App folder | `app/` |
| Settings file | `settings.gradle` at repository top level |
| Workflow | `.github/workflows/build-android.yml` |

If the files are all inside a top-level `BackpackTracker/` folder on GitHub, they were uploaded one level too deep. The workflow must be in `.github/workflows/` at the repository root.

## 3. Build it online

1. Open the repository's **Actions** tab. If prompted to enable Actions, enable it for this repository.
2. Select **Build Android APK** on the left.
3. Select **Run workflow**, leave the default branch selected, then select the confirmation **Run workflow** button.
4. Wait for the run to finish. You can expand it to see progress.
5. A green check means the Android build and lint check succeeded. A red X means there is a build error; open the failed step and send the error text for correction.

No local Gradle setup, setup-windows.ps1 execution, Android SDK installation, or Android Studio installation is needed for this route.

## 4. Download the APK

1. Open the completed green workflow run.
2. Scroll to **Artifacts** and select **BackpackTracker-APK**. You must be signed into GitHub to download it.
3. GitHub downloads a ZIP. Extract it to find **BackpackTracker-test.apk** and `PHONE_INSTALL.txt`.
4. Transfer the APK to your Pixel 7, or open the same GitHub run on your phone and download/extract the artifact there.

This is a debug-signed prototype APK for your own testing, not a Play Store release. A successful build verifies compilation/lint, not Bluetooth operation or field reliability.

## 5. Install and test on the Pixel 7

1. Open the APK from Files on the phone.
2. If Android asks, allow **Install unknown apps** for the browser or Files app you are using. The permission applies to that source app. You can turn it back off after installation.
3. Follow Android's installation prompts. If the phone's security policy blocks installation, note the exact message; a managed school/work phone may require administrator help. Do not disable broad device security protections to bypass a block.
4. Open **Backpack Tracker**. Test with **Manual TEST mode** before connecting any sprayer hardware.
5. Go outdoors, start recording, grant precise location, and toggle the onscreen TEST trigger while walking.
6. Stop the session and export it. Check that `DATALOG1.TXT` includes trigger-active points and `TRAKLOG1.TXT` includes the full route.
7. Follow README.md for XIAO firmware and Hall sensor steps after the app test works.

Each cloud build may use a different temporary debug-signing key. If an update will not install over an older test copy, export all saved sessions FIRST. Removing the old app deletes its private session storage. Only then uninstall the old test copy if needed and install the new build.

## Troubleshooting

| Problem | Next check |
|---|---|
| No Build Android APK workflow | Confirm `.github/workflows/build-android.yml` exists at the repository root on the default branch. |
| No Run workflow button | Select the workflow itself, confirm you own the repository, and reload after the upload completes. |
| Build is blocked by quota | Check GitHub's included Actions allowance and account restrictions. Do not enable paid usage just to proceed; share the message. |
| Red X | Open the run and copy the first meaningful error from the failed step. |
| Only source ZIP downloaded | Download **BackpackTracker-APK** under the completed run's Artifacts, not Code > Download ZIP. |
| Artifact expired | Manually run the workflow again. Artifacts last seven days. |

References:

- Run a workflow: https://docs.github.com/en/actions/how-tos/manage-workflow-runs/manually-run-a-workflow
- Download artifacts: https://docs.github.com/en/actions/how-tos/manage-workflow-runs/download-workflow-artifacts
- Private repository allowances: https://docs.github.com/en/billing/concepts/product-billing/github-actions
- Gradle setup: https://github.com/gradle/actions/blob/main/setup-gradle/README.md

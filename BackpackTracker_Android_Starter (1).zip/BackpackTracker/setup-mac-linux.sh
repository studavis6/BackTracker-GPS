#!/bin/sh
set -eu
PROJECT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
WRAPPER="$PROJECT_DIR/gradle/wrapper/gradle-wrapper.jar"
TEMP="$WRAPPER.download"
trap 'rm -f "$TEMP"' EXIT
curl -fL 'https://raw.githubusercontent.com/gradle/gradle/v8.9.0/gradle/wrapper/gradle-wrapper.jar' -o "$TEMP"
EXPECTED=$(curl -fsSL 'https://services.gradle.org/distributions/gradle-8.9-wrapper.jar.sha256' | tr -d '\r\n ')
if command -v sha256sum >/dev/null 2>&1; then
    ACTUAL=$(sha256sum "$TEMP" | cut -d ' ' -f 1)
else
    ACTUAL=$(shasum -a 256 "$TEMP" | cut -d ' ' -f 1)
fi
if [ "${#EXPECTED}" -ne 64 ] || [ "$ACTUAL" != "$EXPECTED" ]; then
    echo 'Gradle wrapper checksum mismatch' >&2; exit 1
fi
mv "$TEMP" "$WRAPPER"
chmod +x "$PROJECT_DIR/gradlew"
echo 'Gradle wrapper verified. Open this folder in Android Studio.'

package org.backpacktracker;

import java.io.IOException;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** Pure Java recording rules, independent of Android and BLE. Times for scheduling are monotonic. */
public final class RecordingEngine {
    public static final String HEADER = "Date,Time_UTC,Latitude,Longitude,Elevation,Speed(m/s),FixType";
    public enum State { UNKNOWN, OFF, ON }
    public static final long MAX_FIX_AGE_MS = 5000;
    public static final double MAX_ACCURACY_M = 25;
    public static final long HEARTBEAT_TIMEOUT_MS = 3500;
    public static final class Fix {
        public final long utcMs, elapsedMs;
        public final double latitude, longitude, altitudeMsl, speed, accuracy;
        public Fix(long utcMs, long elapsedMs, double latitude, double longitude,
                   double altitudeMsl, double speed, double accuracy) {
            this.utcMs = utcMs; this.elapsedMs = elapsedMs;
            this.latitude = latitude; this.longitude = longitude;
            this.altitudeMsl = altitudeMsl; this.speed = speed; this.accuracy = accuracy;
        }
        public boolean usable(long now) {
            return now >= elapsedMs && now - elapsedMs <= MAX_FIX_AGE_MS
                && Double.isFinite(latitude) && Math.abs(latitude) <= 90
                && Double.isFinite(longitude) && Math.abs(longitude) <= 180
                && Double.isFinite(accuracy) && accuracy >= 0 && accuracy <= MAX_ACCURACY_M;
        }
    }
    public interface Sink {
        void track(Fix fix) throws IOException;
        void spray(Fix fix) throws IOException;
        void event(long utcMs, State state, String reason) throws IOException;
    }
    private final Sink sink;
    private long lastTrack, lastSpray = Long.MIN_VALUE / 2;
    private long lastTrackFix = Long.MIN_VALUE, lastSprayFix = Long.MIN_VALUE;
    private State previous;
    public RecordingEngine(long startElapsedMs, Sink sink) {
        this.lastTrack = startElapsedMs; this.sink = sink;
    }
    public void tick(long now, long utcMs, Fix fix, State state, String reason) throws IOException {
        boolean rising = state == State.ON && previous != State.ON;
        if (state != previous) { sink.event(utcMs, state, reason); previous = state; }
        if (fix == null || !fix.usable(now)) return;
        if (now - lastTrack >= 3000 && fix.elapsedMs != lastTrackFix) {
            sink.track(fix); lastTrack = now; lastTrackFix = fix.elapsedMs;
        }
        if (state == State.ON && (rising || now - lastSpray >= 1000)
                && fix.elapsedMs != lastSprayFix) {
            sink.spray(fix); lastSpray = now; lastSprayFix = fix.elapsedMs;
        }
    }
    public static State sensorState(long now, long heartbeatAt, boolean on) {
        if (heartbeatAt < 0 || now < heartbeatAt || now - heartbeatAt >= HEARTBEAT_TIMEOUT_MS)
            return State.UNKNOWN;
        return on ? State.ON : State.OFF;
    }
    public static String csv(Fix f) {
        Instant t = Instant.ofEpochMilli(f.utcMs);
        return DateTimeFormatter.ISO_LOCAL_DATE.withZone(ZoneOffset.UTC).format(t) + ","
            + DateTimeFormatter.ofPattern("HH:mm:ss", Locale.US).withZone(ZoneOffset.UTC).format(t) + ","
            + String.format(Locale.US, "%.6f,%.6f,%s,%s,GPS Fix", f.latitude, f.longitude,
                number(f.altitudeMsl), number(f.speed));
    }
    private static String number(double value) {
        return Double.isFinite(value) ? String.format(Locale.US, "%.2f", value) : "";
    }
}

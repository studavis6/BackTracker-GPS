# Backpack Tracker for Android — prototype source project

Built from the recording format in your uploaded `Primary_Code.ino`.
Use your Pixel 7 for GPS and the Seeed Studio XIAO nRF52840 for a Bluetooth Hall-sensor connection.

**Start here:** this ZIP contains source code and instructions, not an APK you can tap to install.
The plain Java recording/export code was compiled and tested. The Android app and the XIAO firmware have NOT been built against their SDKs or tested on hardware in this environment.
**If Android Studio is too large for your computer, use BUILD_IN_BROWSER.md instead.** It explains how to upload this small project to a private GitHub repository, run the included build workflow, and download the APK. No local development software is required for that route. The cloud build has not been run yet.

Alternatively, Android Studio on Windows, Mac, or Linux can build/install the app using the local steps below. First build downloads need internet. Actual recording uses GPS and Bluetooth locally and does not require cell service or a paid mapping account.

## What the uploaded code actually produces

| Original file | Contents | Intended interval |
|---|---|---|
| DATALOG#.TXT | GPS positions while the input is LOW / trigger active | About 1 second |
| TRAKLOG#.TXT | GPS positions along the entire route | About 3 seconds |

Both files have this exact CSV header:

```csv
Date,Time_UTC,Latitude,Longitude,Elevation,Speed(m/s),FixType
```

The supplied Arduino code itself does **not** create a map, calculate acreage, measure herbicide flow, or record herbicide volume. If the project includes a separate map-processing script or example map, supply that too to match its styling/calculations.

## This app's output

Each stopped session exports as a ZIP containing:

- `DATALOG1.TXT`: trigger-active points with the original header, approximately every second.
- `TRAKLOG1.TXT`: full route points with the original header, approximately every three seconds.
- `EVENTS.csv`: UTC trigger transitions, UNKNOWN states, and session stop information.
- `POINTS.csv`: coordinates, accuracy, and whether a point is ROUTE or TRIGGER_ON.
- `points.geojson`: GIS-ready discrete points with the same categories and accuracy.
- `SESSION_README.txt`: the session's mode and interpretation notes.

Filenames start at 1 within each uniquely named session folder, rather than increasing forever on an SD card. Session names use UTC. The phone keeps earlier sessions so you can export them again. Export before uninstalling or clearing app storage: those actions delete internal sessions.

The app also includes an offline route sketch: gray route, green trigger points. It is not a street/aerial basemap, does not show a treatment-width polygon, and shows only recent points during long sessions. Exports keep all recorded points.

### Intentional differences from the original code

- The app uses the phone's GPS instead of the original GPS receiver.
- Trigger onset can record immediately, improving capture of short trigger pulls.
- A point is excluded if its reported accuracy is worse than 25 m or its age exceeds 5 seconds. The limit is a filter, not a guarantee of 25 m accuracy.
- Identical GPS fixes are not repeated within one log. Actual sampling frequency can be slower when the phone supplies fewer fixes. No points are invented to fill gaps.
- `FixType` says `GPS Fix`. The original code incorrectly interprets NMEA fix-quality codes as 2D/3D. Phone GPS does not supply the same fix-quality field.
- Elevation is mean-sea-level meters **only if Android supplies MSL altitude**; otherwise blank. This avoids silently substituting ellipsoid height for the original receiver's MSL height.
- Speed is meters/second when available, otherwise blank.
- Sensor state is UNKNOWN before the first valid reading, immediately upon disconnection, or after 3.5 seconds without a heartbeat. No trigger-active points are written during UNKNOWN. The full route continues if GPS remains usable.
- Event times use the phone's clock; coordinate times use GPS location timestamps. A trigger point may use the most recent accepted fix, up to 5 seconds old. Very short trigger events can be missed during a radio interruption; the board does not replay events.

## 1. Install the Android app on your Pixel 7

1. Download and unzip this project **on your computer** into a normal folder you can find.
2. Install Android Studio from https://developer.android.com/studio . Run it once and accept its SDK setup.
3. Prepare the Gradle wrapper (the small official wrapper JAR could not be downloaded in this build environment):
   - **Windows:** open PowerShell in the unzipped `BackpackTracker` folder and run `powershell -ExecutionPolicy Bypass -File .\setup-windows.ps1` . This bypass applies only to that invocation. The script downloads the official Gradle wrapper and verifies its published SHA-256 checksum.
   - **Mac/Linux:** open Terminal in that folder and run `sh setup-mac-linux.sh` .
   - The scripts need internet access to GitHub and Gradle. They do not install the app or change phone settings.
4. In Android Studio, select **Open**, then choose the `BackpackTracker` folder containing `settings.gradle`.
5. Allow Gradle sync. Install **Android SDK Platform 35** if prompted. This project uses Android Gradle Plugin 8.7.3 / Gradle 8.9. Select JDK 17 for Gradle if prompted; Android Studio can download one in Settings > Build Tools > Gradle.
6. On the Pixel 7, open **Settings > About phone > Build number**. Tap Build number seven times and unlock when asked.
7. Open **Settings > System > Developer options**, then enable **USB debugging**.
8. Connect the phone to your computer with a USB **data** cable. Unlock it and accept the USB debugging prompt for your computer.
9. Select your Pixel 7 in Android Studio's device menu, then click the green **Run** triangle.
10. Allow precise location while using the app. Allow notifications so the recording indicator and Stop action are visible. When using sensor mode, allow Nearby devices too.

No Play Store publishing is needed to test on your own phone. An Android build or install error must be resolved before the prototype can be used; send the exact error text for troubleshooting.

## 2. Test the app BEFORE building the sensor

1. Take the phone outdoors, with Location enabled.
2. Open Backpack Tracker and turn on **Manual TEST mode**.
3. Tap **Start session**. Wait for the GPS status to say accepted.
4. Walk for 20–30 seconds. Toggle the TEST trigger on, walk, and toggle it off.
5. Lock the screen briefly, unlock, and verify route point counts increased.
6. Tap Stop session, then **Export a stopped session (.zip)**. Choose a location in Files/Downloads.
7. Open the ZIP and check both text files. Green points and DATALOG rows should correspond to manual trigger-on periods. These sessions are labeled MANUAL TEST in their notes and events.

Start each session with the app visible. A foreground recording service and notification maintain location/Bluetooth recording with the screen locked. Force-stopping the app, turning off the phone, disabling permissions, and some system power restrictions stop or impair recording. There is no automatic session restart after a process death; already flushed files remain exportable. The recording wake lock increases battery use. Test screen-off operation on your specific phone/software before field use.

## 3. Program the XIAO board

1. Install Arduino IDE from https://www.arduino.cc/en/software .
2. Follow Seeed's current board installation guide: https://wiki.seeedstudio.com/XIAO_BLE/ . Add its board-manager URL:
   `https://files.seeedstudio.com/arduino/package_seeeduino_boards_index.json`
3. In Boards Manager, install **Seeed nRF52 Boards** (the **non-mbed** package). This firmware uses its bundled Bluefruit library. Do not choose the similarly named mbed-enabled package.
4. Connect the XIAO nRF52840 to your computer using a USB data cable.
5. Select **Seeed XIAO nRF52840** and the correct serial port.
6. Open `firmware/BackpackSensor/BackpackSensor.ino` and Upload.
7. If the port is not detected, follow Seeed's bootloader instructions (typically a double-tap on reset); select the newly appearing port and upload again.

This source targets the plain XIAO nRF52840 shown in your screenshot. It does not require the Sense version or any GPS/SD module.

## 4. Test Bluetooth without a Hall sensor

1. Power the XIAO by USB (computer or suitable power bank).
2. On the phone, turn Manual TEST mode off, enable Bluetooth, and start a session.
3. Keep only one board running this firmware powered nearby. The prototype connects to the first advertiser with its custom service UUID. It is not a multi-rig device-selection system and does not authenticate the sensor.
4. The app searches for `BackpackSensor`, subscribes, and should show trigger OFF after receiving a reading. You connect **inside the app**; normally you do not pair in Android's Bluetooth settings.
5. Briefly bridge the XIAO's labeled **D0** pad to **GND** using a wire or dry-contact switch. The app should show ON. Remove the bridge: OFF.
6. Unplug the board: the app should show UNKNOWN after disconnect detection / heartbeat expiry, never silently OFF. Re-power it and verify automatic reconnection.

This is a Bluetooth firmware/app package. **USB sensor communication is not implemented in this version**; a USB cable currently powers/programs the XIAO. Do not expect plugging it into the Pixel to supply trigger data to this app.

## 5. Add the actual Hall sensor and magnet

**Do not guess the sensor's pinout. Its model/part number is still needed.**

Proposed wiring is sensor output to D0 and common ground to GND, with an appropriate sensor supply. The XIAO inputs are **3.3 V maximum**. A validated 3.3 V digital/open-drain Hall sensor is a simple option; a 5 V output requires a suitable interface. Do not assume every Hall module sold online is compatible.

The firmware enables an internal pull-up and assumes the trigger-active signal is LOW. If the verified sensor produces the opposite behavior, change `ACTIVE_LOW` in the firmware and upload again. A latching Hall switch may stay in one state after the magnet moves away; choose behavior appropriate to your trigger mechanism. Mounting position determines whether the magnet corresponds to trigger ON or OFF.

For standalone wireless use add a protected, correctly connected battery per Seeed's power documentation and a weatherproof enclosure. For initial bench tests, USB power is sufficient. A phone-power cable may be possible but then the cable is only supplying power; BLE still carries this version's readings.

## 6. Make a map in ArcGIS Pro

1. Extract the session ZIP.
2. For the simplest import, use **JSON To Features** with `points.geojson` and Point geometry.
3. Symbolize by `record_type`: ROUTE and TRIGGER_ON.
4. Alternatively, copy `DATALOG1.TXT` to `DATALOG1.csv` and `TRAKLOG1.TXT` to `TRAKLOG1.csv`. Use **XY Table To Point** with X = Longitude, Y = Latitude, and **GCS WGS 1984 (EPSG:4326)**.
5. Keep trigger points as points initially. Creating one continuous line through all trigger points would incorrectly bridge separate spray bursts. `EVENTS.csv` provides the ON/OFF/UNKNOWN intervals if a later processing script needs separate segments.

Actual treatment width, flow rate, volume, and acreage are not measured by this sensor. Do not treat GPS trigger points as a precise treatment boundary. Validate with water and known locations first.

## Validation included

`tests/RecordingEngineTest.java` checks recording intervals, OFF/UNKNOWN behavior, sensor timeout boundaries, stale/poor GPS rejection, duplicate prevention, UTC formatting, exact CSV headers, and GeoJSON coordinate order. The plain Java tests can run without Android:

```sh
javac -d test-build app/src/main/java/org/backpacktracker/RecordingEngine.java app/src/main/java/org/backpacktracker/SessionWriter.java app/src/main/java/org/backpacktracker/GeoJsonExporter.java tests/RecordingEngineTest.java
java -cp test-build org.backpacktracker.RecordingEngineTest
```

These tests do not substitute for Android SDK compilation, firmware compilation, BLE hardware tests, screen-off tests, field GPS checks, or testing your specific Hall sensor. Those checks remain outstanding.

## Reference documentation

- Android foreground service requirements: https://developer.android.com/develop/background-work/services/fgs/service-types
- Android BLE background operation: https://developer.android.com/develop/connectivity/bluetooth/ble/background
- Seeed board setup and voltage limits: https://wiki.seeedstudio.com/XIAO_BLE/
- Seeed Bluefruit examples: https://wiki.seeedstudio.com/XIAO-BLE-Sense-Bluetooth_Usage/

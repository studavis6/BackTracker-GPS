package org.backpacktracker;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.location.*;
import android.os.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Locale;

public final class TrackerService extends Service implements LocationListener {
    public static final String START = "org.backpacktracker.START", STOP = "org.backpacktracker.STOP";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final IBinder binder = new LocalBinder();
    public final class LocalBinder extends Binder { public TrackerService getService() { return TrackerService.this; } }
    public boolean recording, manualMode, manualOn;
    public String message = "Ready. Start outdoors with a clear view of the sky.";
    public String sensorMessage = "Not recording";
    public RecordingEngine.State trigger = RecordingEngine.State.UNKNOWN;
    public int routeCount, sprayCount;
    public RecordingEngine.Fix latest;
    public final ArrayList<PlotPoint> preview = new ArrayList<>();
    public static final class PlotPoint {
        public final RecordingEngine.Fix fix;
        public final boolean spray;
        PlotPoint(RecordingEngine.Fix f, boolean s) { fix = f; spray = s; }
    }
    private SessionWriter writer;
    private RecordingEngine engine;
    private LocationManager locations;
    private BleSensor ble;
    private PowerManager.WakeLock wakeLock;
    private long heartbeatAt = -1;
    private boolean sensorOn;
    private File sessionDir;

    @Override public IBinder onBind(Intent intent) { return binder; }
    @Override public void onCreate() {
        super.onCreate();
        getSystemService(NotificationManager.class).createNotificationChannel(new NotificationChannel(
            "recording", "Recording sessions", NotificationManager.IMPORTANCE_LOW));
        locations = getSystemService(LocationManager.class);
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && STOP.equals(intent.getAction())) finishSession("SESSION_STOPPED");
        else if (intent != null && START.equals(intent.getAction()) && !recording)
            begin(intent.getBooleanExtra("manual", false));
        return START_NOT_STICKY; // Never silently restart a session without fresh user action.
    }
    private Notification notification() {
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop = PendingIntent.getService(this, 1, new Intent(this, TrackerService.class).setAction(STOP),
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, "recording")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Backpack Tracker recording")
            .setContentText(manualMode ? "Manual TEST mode • tap to view" : "Bluetooth sensor mode • tap to view")
            .setContentIntent(open).setOngoing(true)
            .addAction(new Notification.Action.Builder(null, "Stop", stop).build()).build();
    }
    @SuppressLint({"MissingPermission", "WakelockTimeout"})
    private void begin(boolean manual) {
        manualMode = manual; manualOn = false; heartbeatAt = -1; latest = null;
        trigger = RecordingEngine.State.UNKNOWN; preview.clear(); routeCount = sprayCount = 0;
        try {
            int types = ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION;
            if (!manualMode) types |= ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE;
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, notification(), types);
            else startForeground(1, notification());
            String id = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss_SSS", Locale.US)
                .withZone(ZoneOffset.UTC).format(Instant.now());
            sessionDir = new File(new File(getFilesDir(), "sessions"), "Session_" + id);
            if (!sessionDir.mkdirs()) throw new IOException("Cannot create session folder");
            writeNotes();
            writer = new SessionWriter(sessionDir);
            engine = new RecordingEngine(SystemClock.elapsedRealtime(), new RecordingEngine.Sink() {
                @Override public void track(RecordingEngine.Fix fix) throws IOException {
                    writer.track(fix); routeCount = writer.trackCount; addPreview(fix, false);
                }
                @Override public void spray(RecordingEngine.Fix fix) throws IOException {
                    writer.spray(fix); sprayCount = writer.sprayCount; addPreview(fix, true);
                }
                @Override public void event(long utc, RecordingEngine.State state, String reason) throws IOException {
                    writer.event(utc, state, reason);
                }
            });
            wakeLock = getSystemService(PowerManager.class).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                "BackpackTracker:recording");
            wakeLock.acquire();
            recording = true;
            message = "Recording " + sessionDir.getName() + (manualMode ? " — MANUAL TEST" : "");
            sensorMessage = manualMode ? "Manual test button" : "Connecting";
            locations.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0, this, Looper.getMainLooper());
            if (!manualMode) {
                ble = new BleSensor(this, handler, new BleSensor.Listener() {
                    @Override public void status(String text) { sensorMessage = text; }
                    @Override public void reading(boolean on) {
                        sensorOn = on; heartbeatAt = SystemClock.elapsedRealtime(); sample();
                    }
                    @Override public void lost() { heartbeatAt = -1; sample(); }
                });
                ble.start();
            }
            handler.post(poll);
        } catch (Exception e) { fail(e); }
    }
    private void addPreview(RecordingEngine.Fix f, boolean spray) {
        preview.add(new PlotPoint(f, spray));
        if (preview.size() > 5000) preview.subList(0, 500).clear();
    }
    private void writeNotes() throws IOException {
        String notes = "Backpack Tracker Android prototype v0.1\n"
            + "Session started UTC: " + Instant.now() + "\n"
            + "Mode: " + (manualMode ? "MANUAL TEST — not sensor-observed" : "BLE Hall sensor") + "\n\n"
            + "DATALOG1.TXT: locations while trigger ON; approximately 1 second.\n"
            + "TRAKLOG1.TXT: full walking route; approximately 3 seconds.\n"
            + "Each session has its own folder, so filenames use 1 in each folder.\n"
            + "Both use the uploaded Primary_Code.ino's CSV column names.\n"
            + "Latitude/Longitude: WGS84 decimal degrees; west/south negative.\n"
            + "Elevation: mean sea level meters only when Android supplies it; otherwise blank.\n"
            + "Speed(m/s): meters per second when supplied; otherwise blank.\n"
            + "FixType: GPS Fix; Android does not expose the original receiver's fix-quality value.\n"
            + "Only GPS-provider readings, age <=5s and reported horizontal accuracy <=25m are logged.\n"
            + "This accuracy threshold is a filter, not a guarantee of actual accuracy.\n"
            + "Each GPS fix is logged at most once per file. No backfilling during GPS gaps.\n"
            + "Trigger onset may record immediately, improving short-trigger capture over original code.\n"
            + "EVENTS.csv: UTC phone event times; ON/OFF/UNKNOWN; session end marker.\n"
            + "POINTS.csv: per-point accuracy and record type for GIS import.\n"
            + "Sensor heartbeat every 1s; UNKNOWN after 3.5s with no heartbeat or immediately on disconnect.\n"
            + "No trigger points are logged while sensor state is UNKNOWN. Route logging continues.\n"
            + "Phone GPS times may precede trigger event times by up to the allowed fix age.\n"
            + "No sensor event buffering/replay; radio interruptions can lose short trigger events.\n"
            + "A trigger pull is not proof of flow, dose, treated area, or legal reporting completeness.\n"
            + "No SESSION_STOPPED/INTERRUPTED marker means recording may have ended unexpectedly.\n"
            + "Do not join trigger points across OFF/UNKNOWN events into a single treatment line.\n";
        try (FileOutputStream out = new FileOutputStream(new File(sessionDir, "SESSION_README.txt"))) {
            out.write(notes.getBytes(StandardCharsets.UTF_8));
        }
    }
    private final Runnable poll = new Runnable() {
        @Override public void run() { if (recording) { sample(); if (recording) handler.postDelayed(this, 100); } }
    };
    private void sample() {
        if (!recording || engine == null) return;
        long now = SystemClock.elapsedRealtime();
        trigger = manualMode ? (manualOn ? RecordingEngine.State.ON : RecordingEngine.State.OFF)
            : RecordingEngine.sensorState(now, heartbeatAt, sensorOn);
        String reason = manualMode ? "MANUAL_TEST" : (trigger == RecordingEngine.State.UNKNOWN
            ? "NO_RECENT_SENSOR_READING" : "BLE_SENSOR");
        try { engine.tick(now, System.currentTimeMillis(), latest, trigger, reason); }
        catch (IOException e) { fail(e); }
    }
    public void toggleManual() { if (recording && manualMode) { manualOn = !manualOn; sample(); } }
    @Override public void onLocationChanged(Location l) {
        if (!recording || !LocationManager.GPS_PROVIDER.equals(l.getProvider())) return;
        double altitude = Double.NaN;
        if (Build.VERSION.SDK_INT >= 34 && l.hasMslAltitude()) altitude = l.getMslAltitudeMeters();
        latest = new RecordingEngine.Fix(l.getTime(), l.getElapsedRealtimeNanos() / 1000000,
            l.getLatitude(), l.getLongitude(), altitude, l.hasSpeed() ? l.getSpeed() : Double.NaN,
            l.hasAccuracy() ? l.getAccuracy() : Double.NaN);
    }
    @Override public void onProviderDisabled(String provider) { if (LocationManager.GPS_PROVIDER.equals(provider)) latest = null; }
    @Override public void onProviderEnabled(String provider) {}
    @Override public void onStatusChanged(String provider, int status, Bundle extras) {}
    private void fail(Exception e) {
        String detail = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
        finishSession("INTERRUPTED_ERROR"); message = "Recording stopped: " + detail + ". Existing files can be exported.";
    }
    private void finishSession(String reason) {
        boolean hadSession = recording;
        recording = false; handler.removeCallbacks(poll);
        if (ble != null) { ble.close(); ble = null; }
        if (locations != null) { try { locations.removeUpdates(this); } catch (RuntimeException ignored) {} }
        if (writer != null) {
            String error = null;
            try { writer.event(System.currentTimeMillis(), trigger, reason); }
            catch (IOException e) { error = e.getMessage(); }
            try { writer.close(); } catch (IOException e) { error = e.getMessage(); }
            writer = null;
            if (error != null) {
                message = "Session stopped with a file error: " + error;
                hadSession = false; // Preserve the error message below.
            }
        }
        engine = null;
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        wakeLock = null;
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf();
        if (hadSession) message = "Session stopped. Export your files below.";
        sensorMessage = "Not recording";
    }
    @Override public void onDestroy() { finishSession("INTERRUPTED_SERVICE_DESTROYED"); super.onDestroy(); }
}

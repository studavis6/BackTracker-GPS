package org.backpacktracker;

import android.content.Context;
import android.graphics.*;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

/** Offline route sketch, deliberately not a basemap or an acreage calculation. */
public final class RouteView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<TrackerService.PlotPoint> points = new ArrayList<>();
    public RouteView(Context c) { super(c); }
    public void setPoints(List<TrackerService.PlotPoint> p) { points.clear(); points.addAll(p); invalidate(); }
    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas); canvas.drawColor(Color.rgb(233, 239, 234));
        paint.setTextSize(30); paint.setColor(Color.DKGRAY);
        if (points.isEmpty()) { canvas.drawText("Route preview appears after GPS records", 20, 55, paint); return; }
        double midLat = points.get(0).fix.latitude;
        double cos = Math.max(0.01, Math.cos(Math.toRadians(midLat)));
        double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
        for (TrackerService.PlotPoint p : points) {
            double x = p.fix.longitude * cos * 111320, y = p.fix.latitude * 111320;
            minX = Math.min(minX, x); maxX = Math.max(maxX, x);
            minY = Math.min(minY, y); maxY = Math.max(maxY, y);
        }
        double scale = Math.min((getWidth() - 60) / Math.max(20, maxX - minX),
            (getHeight() - 60) / Math.max(20, maxY - minY));
        double cx = (minX + maxX) / 2, cy = (minY + maxY) / 2;
        float lastX = 0, lastY = 0; long lastTime = Long.MIN_VALUE / 2;
        paint.setStrokeWidth(4); paint.setColor(Color.rgb(95, 109, 119));
        for (TrackerService.PlotPoint p : points) {
            if (p.spray) continue;
            float x = (float) (getWidth() / 2.0 + (p.fix.longitude * cos * 111320 - cx) * scale);
            float y = (float) (getHeight() / 2.0 - (p.fix.latitude * 111320 - cy) * scale);
            if (p.fix.elapsedMs - lastTime <= 6000) canvas.drawLine(lastX, lastY, x, y, paint);
            canvas.drawCircle(x, y, 3, paint);
            lastX = x; lastY = y; lastTime = p.fix.elapsedMs;
        }
        paint.setColor(Color.rgb(0, 119, 80));
        for (TrackerService.PlotPoint p : points) {
            if (!p.spray) continue;
            float x = (float) (getWidth() / 2.0 + (p.fix.longitude * cos * 111320 - cx) * scale);
            float y = (float) (getHeight() / 2.0 - (p.fix.latitude * 111320 - cy) * scale);
            canvas.drawCircle(x, y, 6, paint);
        }
    }
}

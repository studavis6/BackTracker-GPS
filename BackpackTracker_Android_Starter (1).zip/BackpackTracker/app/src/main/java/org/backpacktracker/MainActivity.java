package org.backpacktracker;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;
import java.util.zip.*;

public final class MainActivity extends Activity {
    private final Handler ui = new Handler(Looper.getMainLooper());
    private TrackerService service;
    private boolean bound;
    private TextView session, gps, sensor, state, count;
    private Button start, stop, manual;
    private Switch testMode;
    private RouteView route;
    private File pendingExport;
    private boolean requestedManual;
    private int plottedCount = -1;
    private final ServiceConnection connection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder binder) {
            service = ((TrackerService.LocalBinder) binder).getService(); refresh();
        }
        @Override public void onServiceDisconnected(ComponentName name) { service = null; }
    };
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        if (saved != null) {
            requestedManual = saved.getBoolean("requestedManual", false);
            String name = saved.getString("export");
            if (name != null && name.startsWith("Session_") && !name.contains("/"))
                pendingExport = new File(new File(getFilesDir(), "sessions"), name);
        }
        LinearLayout body = new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20); body.setPadding(pad, pad, pad, pad); body.setBackgroundColor(Color.rgb(247, 248, 243));
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.addView(body); setContentView(scroll);
        // Edge-to-edge is mandatory at target 35; keep controls outside system bars.
        body.setOnApplyWindowInsetsListener((v, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                body.setPadding(pad + bars.left, pad + bars.top, pad + bars.right, pad + bars.bottom);
            } else body.setPadding(pad, pad + insets.getSystemWindowInsetTop(), pad, pad + insets.getSystemWindowInsetBottom());
            return insets;
        });
        TextView title = label(body, "Backpack Tracker", 28); title.setTextColor(Color.rgb(0, 79, 56));
        label(body, "GPS route + sprayer trigger recording", 16);
        testMode = new Switch(this); testMode.setText("Manual TEST mode (no sensor)"); body.addView(testMode);
        session = label(body, "Ready", 15);
        state = label(body, "TRIGGER: UNKNOWN", 24);
        sensor = label(body, "Not connected", 15);
        gps = label(body, "GPS: waiting", 15);
        count = label(body, "Route points: 0  •  Trigger points: 0", 15);
        start = button(body, "Start session", v -> requestStart());
        manual = button(body, "TEST: trigger OFF — tap to change", v -> { if (service != null) service.toggleManual(); refresh(); });
        stop = button(body, "Stop session", v -> new AlertDialog.Builder(this)
            .setMessage("Stop recording this session?").setNegativeButton("Keep recording", null)
            .setPositiveButton("Stop", (d, w) -> startService(new Intent(this, TrackerService.class).setAction(TrackerService.STOP))).show());
        label(body, "Route preview • gray route / green trigger points", 14);
        route = new RouteView(this); body.addView(route, new LinearLayout.LayoutParams(-1, dp(220)));
        label(body, "Offline sketch, north up. Recent points only; exports contain all logged points.", 12);
        button(body, "Export a stopped session (.zip)", v -> chooseExport());
        label(body, "Trigger state is not proof of liquid flow. GPS readings older than 5 seconds or with reported accuracy worse than 25 m are excluded.", 13);
        label(body, "Prototype: validate against known locations and trigger pulls before field use.", 13);
        refresh();
    }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    private TextView label(LinearLayout parent, String text, int size) {
        TextView view = new TextView(this); view.setText(text); view.setTextSize(size);
        view.setTextColor(Color.rgb(35, 49, 43)); view.setPadding(0, dp(5), 0, dp(5)); parent.addView(view); return view;
    }
    private Button button(LinearLayout parent, String text, View.OnClickListener action) {
        Button button = new Button(this); button.setText(text); button.setAllCaps(false); button.setOnClickListener(action);
        parent.addView(button, new LinearLayout.LayoutParams(-1, -2)); return button;
    }
    @Override protected void onStart() {
        super.onStart(); bound = bindService(new Intent(this, TrackerService.class), connection, BIND_AUTO_CREATE); ui.post(refreshLoop);
    }
    @Override protected void onStop() {
        ui.removeCallbacks(refreshLoop); if (bound) unbindService(connection); bound = false; service = null; super.onStop();
    }
    private final Runnable refreshLoop = new Runnable() {
        @Override public void run() { refresh(); ui.postDelayed(this, 500); }
    };
    private void refresh() {
        if (session == null) return;
        boolean running = service != null && service.recording;
        start.setEnabled(service != null && !running); stop.setEnabled(running); testMode.setEnabled(!running);
        manual.setVisibility(running && service.manualMode ? View.VISIBLE : View.GONE);
        if (service == null) return;
        session.setText(service.message);
        if (running) testMode.setChecked(service.manualMode);
        state.setText("TRIGGER: " + (running ? service.trigger : "—") + (running && service.manualMode ? " (TEST)" : ""));
        state.setTextColor(service.trigger == RecordingEngine.State.ON && running ? Color.rgb(0, 119, 80) : Color.DKGRAY);
        sensor.setText(service.sensorMessage);
        manual.setText("TEST: trigger " + (service.manualOn ? "ON" : "OFF") + " — tap to change");
        RecordingEngine.Fix fix = service.latest;
        if (fix == null) gps.setText("GPS: waiting. Go outdoors; enable precise location.");
        else {
            long age = Math.max(0, SystemClock.elapsedRealtime() - fix.elapsedMs);
            gps.setText(String.format(Locale.US, "GPS: %.6f, %.6f\nReported accuracy: %.1f m • age %.1f s • %s",
                fix.latitude, fix.longitude, fix.accuracy, age / 1000.0,
                fix.usable(SystemClock.elapsedRealtime()) ? "accepted" : "not logging this fix"));
        }
        count.setText("Route points: " + service.routeCount + "  •  Trigger points: " + service.sprayCount);
        int total = service.routeCount + service.sprayCount;
        if (total != plottedCount) { route.setPoints(service.preview); plottedCount = total; }
    }
    private void requestStart() {
        requestedManual = testMode.isChecked();
        ArrayList<String> permissions = new ArrayList<>();
        permissions.add(Manifest.permission.ACCESS_COARSE_LOCATION); permissions.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if (!requestedManual && Build.VERSION.SDK_INT >= 31) {
            permissions.add(Manifest.permission.BLUETOOTH_SCAN); permissions.add(Manifest.permission.BLUETOOTH_CONNECT);
        }
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS);
        ArrayList<String> missing = new ArrayList<>();
        for (String p : permissions) if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) missing.add(p);
        if (!missing.isEmpty()) requestPermissions(missing.toArray(new String[0]), 10);
        else launchRecording();
    }
    @Override public void onRequestPermissionsResult(int request, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(request, permissions, results); if (request == 10) launchRecording();
    }
    private void launchRecording() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            tell("Precise location permission is required. Enable it in Settings > Apps > Backpack Tracker > Permissions."); return;
        }
        if (!requestedManual && Build.VERSION.SDK_INT >= 31
            && (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)) {
            tell("Allow Nearby devices permission to use the sensor."); return;
        }
        try {
            startForegroundService(new Intent(this, TrackerService.class).setAction(TrackerService.START)
                .putExtra("manual", requestedManual));
        } catch (RuntimeException e) { tell("Could not start: " + e.getMessage()); }
    }
    private void chooseExport() {
        if (service != null && service.recording) { tell("Stop the current session before exporting."); return; }
        File root = new File(getFilesDir(), "sessions");
        File[] dirs = root.listFiles(f -> f.isDirectory() && f.getName().startsWith("Session_"));
        if (dirs == null || dirs.length == 0) { tell("No sessions yet. Start a manual test outdoors first."); return; }
        Arrays.sort(dirs, (a,b) -> b.getName().compareTo(a.getName()));
        String[] names = new String[dirs.length]; for (int i = 0; i < dirs.length; i++) names[i] = dirs[i].getName();
        new AlertDialog.Builder(this).setTitle("Choose session (UTC)").setItems(names, (d, which) -> {
            pendingExport = dirs[which];
            Intent create = new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                .setType("application/zip").putExtra(Intent.EXTRA_TITLE, pendingExport.getName() + ".zip");
            startActivityForResult(create, 20);
        }).show();
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != 20 || result != RESULT_OK || data == null || data.getData() == null || pendingExport == null) return;
        File source = pendingExport; android.net.Uri dest = data.getData();
        new Thread(() -> {
            try (OutputStream output = getContentResolver().openOutputStream(dest, "w")) {
                if (output == null) throw new IOException("Destination could not be opened");
                try (ZipOutputStream zip = new ZipOutputStream(output)) {
                    File[] files = source.listFiles(File::isFile);
                    if (files == null) throw new IOException("Session folder missing");
                    Arrays.sort(files, Comparator.comparing(File::getName));
                    byte[] buffer = new byte[8192];
                    for (File file : files) {
                        zip.putNextEntry(new ZipEntry(file.getName()));
                        try (FileInputStream input = new FileInputStream(file)) {
                            int read; while ((read = input.read(buffer)) != -1) zip.write(buffer, 0, read);
                        }
                        zip.closeEntry();
                    }
                    File points = new File(source, "POINTS.csv");
                    if (points.isFile()) {
                        zip.putNextEntry(new ZipEntry("points.geojson"));
                        GeoJsonExporter.write(points, zip); zip.closeEntry();
                    }
                }
                runOnUiThread(() -> tell("Session exported. Open the ZIP to find DATALOG1.TXT and TRAKLOG1.TXT."));
            } catch (Exception e) { runOnUiThread(() -> tell("Export failed: " + e.getMessage() + ". The original session remains on this phone.")); }
        }, "session-export").start();
    }
    @Override protected void onSaveInstanceState(Bundle out) {
        out.putBoolean("requestedManual", requestedManual);
        if (pendingExport != null) out.putString("export", pendingExport.getName()); super.onSaveInstanceState(out);
    }
    private void tell(String message) { new AlertDialog.Builder(this).setMessage(message).setPositiveButton("OK", null).show(); }
}
